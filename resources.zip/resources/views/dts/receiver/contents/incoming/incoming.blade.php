@extends('dts.receiver.layout.receiver_master')
@section('title', $title)
@section('content')
@include('global_includes.title')
@include('dts.receiver.contents.incoming.sections.incoming_table')
@include('dts.receiver.contents.incoming.modal.final_action_modal')
@include('dts.receiver.contents.incoming.modal.add_note_modal')
@endsection



@section('js')
@include('dts.includes.datatable')
<script type="text/javascript">
  $('a.received_document').on('click', function() {

    var id = $(this).data('id');
    var track = $(this).data('track');
    Swal.fire({
      title: "Are you sure?",
      text: "",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Received Document"
    }).then((result) => {
      if (result.isConfirmed) {
        received_document(id,track);
      }
    });
  });

  function received_document(id,track) {
    let data = {
      id: id,
      tracking_number : track
    };

    var url = '/dts/us/receive-document';

    $.ajax({
      url: base_url + url,
      method: 'POST',
      data: data,
      dataType: 'json',
      beforeSend : function(){
            loader();
      },
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
      },
      success: function(data) {
        JsLoadingOverlay.hide();
        if(data.response) {
          Swal.fire({
                  position: "top-end",
                  icon: "success",
                  title: data.message,
                  showConfirmButton: false,
                  timer: 1500
               });
          $('#final_action_modal').modal('show');
          $('#forward_form').find('input[name=id]').val(data.id);
          $('#forward_form').find('input[name=t_number]').val(data.tracking_number);
        }else {
          alert('something Wrong');
          
          // location.reload();
        }
      },
      error: function() {
        JsLoadingOverlay.hide();
        alert('something Wrong')
      }

    });


  }

  $('#forward_form').on('submit', function (e) {
   e.preventDefault();
   var url = '/dts/r/complete-document';
   var form = $(this).serialize();
   add_item(form,url);

});

$('form#update_note').on('submit', function (e) {
   e.preventDefault();
   var url = '/dts/r/a-n';
   var form = $(this).serialize();
   add_item(form,url);

});


$('button.update_note').on('click', function() {
  $('#update_note').attr('hidden',false);
  $(this).attr('hidden',true);

  //  
});

$('button.close_add_note').on('click', function() {
  $('#update_note').attr('hidden',true);
  $('button.update_note').attr('hidden',false);
});


$('a.add-note').on('click', function() {

    $('#add_note_modal').modal('show');
    var document_id = $(this).data('id');
    $('#update_note').attr('hidden',true);
    $('button.update_note').attr('hidden',false);
    $('input[name=document_id]').val(document_id);
    var note = $(this).data('note')
    $('#add_note_modal').find('p.note').text(note);
    $('textarea[name=note]').val(note);


});
</script>

@endsection