<div class="card flex-fill p-3">
         <div class="card-header">
            <h5 class="card-title mb-0">Documents</h5>
         </div>
         <table class="table table-hover table-striped " id="datatable_with_select" style="width: 100%; "  >
            <thead>
               <tr>
                  <th>Action</th>
                  <th>#</th>
                  <th>Tracking Number</th>
                  <th>Document Name</th>
                  <th>From</th>
                  <th>Document Type</th>
                  <th>Remarks</th>
                  <th>Released Date - Time</th>
                  
               </tr>
            </thead>
            <tfoot>
               <tr>
                  <th>Action</th>
                  <th>#</th>
                  <th>Tracking Number</th>
                  <th>Document Name</th>
                  <th>From</th>
                  <th>Document Type</th>
                  <th>Remarks</th>
                  <th>Released Date - Time</th>
                  
               </tr>
            </tfoot>
           
         </table>
      </div>
