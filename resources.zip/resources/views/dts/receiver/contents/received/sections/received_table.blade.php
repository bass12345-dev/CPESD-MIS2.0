<div class="card flex-fill p-3">
         <div class="card-header">
            <h5 class="card-title mb-0">Documents</h5>
         </div>
         <table class="table table-hover table-striped " id="datatable_with_select" style="width: 100%; "  >
            <thead>
               <tr>
                  <th>#</th>
                  <th>Tracking Number</th>
                  <th>Document Name</th>
                  <th>Document Type</th>
                  <th>Remarks</th>
                  <th>Received Date - Time</th>
                  <th>Actions</th>
               </tr>
            </thead>
           
         </table>
      </div>




