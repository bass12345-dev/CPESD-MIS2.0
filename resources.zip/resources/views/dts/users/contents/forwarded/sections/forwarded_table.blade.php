<div class="card flex-fill p-3">
         <div class="card-header">
            <h5 class="card-title mb-0">Documents</h5>
         </div>
         <table class="table table-hover table-striped " id="datatables-buttons" style="width: 100%; "  >
            <thead>
               <tr>
                  <th>#</th>
                  <th>Tracking Number</th>
                  <th>Document Name</th>
                  <th>Forwarded To</th>
                  <th>Document Type</th>
                  <th>Remarks</th>
                  <th>Released Date - Time</th>
                  <th>Actions</th>
               </tr>
            </thead>
            <tfoot>
               <tr>
                  <th>#</th>
                  <th>Tracking Number</th>
                  <th>Document Name</th>
                  <th>Forwarded To</th>
                  <th>Document Type</th>
                  <th>Remarks</th>
                  <th>Released Date - Time</th>
                  <th>Actions</th>
               </tr>
            </tfoot>
         </table>
      </div>




