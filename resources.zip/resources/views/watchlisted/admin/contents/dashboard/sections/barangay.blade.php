<div class="col-12 col-lg-12 col-xxl-12 d-flex">
	<div class="card flex-fill w-100">
		<div class="card-header">

			<h5 class="card-title mb-0">Data Per Barangay</h5>
		</div>
		<div class="card-body d-flex w-100" style="border: 1px solid;">
			<div class="align-self-center chart chart-lg">
				<canvas id="chartjs-dashboard-bar" style="height: 300vh;"></canvas>
			</div>
		</div>
	</div>
</div>