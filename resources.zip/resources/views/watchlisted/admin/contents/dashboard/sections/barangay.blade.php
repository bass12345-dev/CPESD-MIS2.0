<div class="col-12 col-lg-12 col-xxl-12 d-flex">
	<div class="card  w-100 " style="border: 1px solid;">
		
		<div class="card-body d-flex w-100" >
			<div class="align-self-center chart chart-lg">
				<canvas id="chartjs-dashboard-bar" style="height: 150px;"></canvas>
			</div>
		</div>
	</div>
</div>