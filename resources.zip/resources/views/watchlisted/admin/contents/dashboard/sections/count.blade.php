<div class="row">
   <div class="col-xl-12 col-xxl-12 d-flex">
      <div class="w-100">
         <div class="row">
            <div class="col-sm-4">
               <div class="card l-bg-cherry">
                  <div class="card-body">
                     <div class="row">
                        <div class="col mt-0">
                           <h5 class="card-title text-white">Watchlist</h5>
                        </div>
                        <div class="col-auto">
                           <div class="stat text-primary">
                              <i class="align-middle" data-feather="alert-circle"></i>
                           </div>
                        </div>
                     </div>
                     <h1 class="mt-1 mb-3 text-white">{{$count_active->original[0]['active']}}</h1>
                  </div>
               </div>
            </div>
            
  
         </div>
      </div>
   </div>
</div>