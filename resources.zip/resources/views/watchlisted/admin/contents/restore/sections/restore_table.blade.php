<div class="card flex-fill p-3">
         <div class="card-header">
            <h5 class="card-title mb-2">Restore</h5>
            <button class="btn btn-danger" id="delete"> Delete</button>
            <button class="btn btn-success" id="restore"> Set to active</button>
            <hr>
         </div>
         

         <table class="table table-hover table-striped " id="datatable_with_select" style="width: 100%; "  >
            <thead>
               <tr>
                  <th></th>
                  <th>#</th>
                  <th>Name</th>
                  <th>Age</th>
                  <th>Address</th>
                  <th>Email</th>
                  <th>Phone Number</th>
                 
               </tr>
            </thead>

         </table>
      </div>




